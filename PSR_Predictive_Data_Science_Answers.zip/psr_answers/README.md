# 231CSV65 – Predictive Data Science: Case Study Answers

| Q | File | Language |
|---|------|----------|
| 1 | `01_case_study_answers.md` (parts a–f) | Written answers |
| 2 | `02_simple_linear_regression.py` | Python |
| 3 | `03_logistic_regression.py` | Python |
| 4 | `04_svm_decision_tree.py` | Python |
| 5 | `05_naive_bayes.py` | Python |
| 6 | `06_market_basket_analysis.py` | Python (Apriori, no extra package) |
| 7 | `07_breast_cancer_prediction.R` | R |
| 8 | `08_hr_analytics_demand_forecast.R` | R |

`outputs/` holds the plots produced by running the Python programs.

## Setup
Python: `pip install numpy pandas scikit-learn matplotlib`, then `python 02_simple_linear_regression.py` etc.

R: `install.packages(c("caret", "e1071", "randomForest"))`, then `Rscript 07_breast_cancer_prediction.R`.
Q7 downloads the WDBC dataset from the UCI repository, so it needs internet.
